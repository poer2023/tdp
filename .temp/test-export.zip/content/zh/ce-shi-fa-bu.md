---
title: "测试发布"
date: "2025-09-30T18:22:49.900Z"
slug: "ce-shi-fa-bu"
locale: "ZH"
groupId: "grp_fc98b8a79cf04efe0ea0dca5"
tags:
  - "学习"
status: "PUBLISHED"
excerpt: "测试发布文章，一会儿就行"
cover: "../uploads/uploads/covers/a4421d362c75440695f137158cf9fc8b.jpeg"
author: "cmg6p8mw40000gcgfi9crkluc"
publishedAt: "2025-09-30T18:22:49.896Z"
---

测试发布文章，## Error Type
Runtime Error

## Error Message
An unexpected response was received from the server.


    at AdminGalleryPage (src/app/admin/gallery/page.tsx:22:7)

## Code Frame
  20 |       </header>
  21 |
> 22 |       <GalleryUploadForm posts={posts} />
     |       ^
  23 |
  24 |       <section className="space-y-4">
  25 |         <div className="flex items-center justify-between">

Next.js version: 15.5.4 (Turbopack)
，
