---
title: "Test English Post"
date: "2025-10-01T08:30:41.966Z"
slug: "test-english-post"
locale: "EN"
groupId: "grp_b629475375f994f35c1c6408"
tags: []
status: "PUBLISHED"
excerpt: "This is a test"
author: "cmg6p8mw40000gcgfi9crkluc"
publishedAt: "2025-10-01T08:30:41.966Z"
---

Test content
